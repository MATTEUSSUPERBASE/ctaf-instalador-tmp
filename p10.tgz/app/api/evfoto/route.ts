import {NextResponse} from 'next/server';import sharp from 'sharp';import path from 'path';import crypto from 'crypto';import {DATA} from '@/lib/db';import {getSession} from '@/lib/auth';
export async function POST(req:Request){if(!(await getSession()))return NextResponse.json({erro:'x'},{status:401});
 const fd=await req.formData();const f=fd.get('file') as File|null;if(!f||f.size>20e6)return NextResponse.json({erro:'arquivo'},{status:400});
 const name=`ev-${crypto.randomBytes(6).toString('hex')}.jpg`;
 try{await sharp(Buffer.from(await f.arrayBuffer())).rotate().resize({width:1600,height:1600,fit:'inside',withoutEnlargement:true}).jpeg({quality:85}).toFile(path.join(DATA,'uploads',name))}catch{return NextResponse.json({erro:'imagem'},{status:400})}
 return NextResponse.json({ok:1,file:name})}
