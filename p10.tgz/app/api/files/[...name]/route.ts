import fs from 'fs';import path from 'path';import {DATA} from '@/lib/db';import {CLUB_DIR} from '@/lib/club';
const T:any={'.png':'image/png','.mp4':'video/mp4','.jpg':'image/jpeg'};
export async function GET(req:Request,{params}:{params:Promise<{name:string[]}>}){const {name}=await params;
 const club=name[0]==='_club';const base=path.basename(name[name.length-1]);const f=club?path.join(CLUB_DIR,base):path.join(DATA,base.endsWith('-cut.png')||base.startsWith('sp-')||base.startsWith('adv-')||base.startsWith('ev-')?'uploads':'out',base);
 if(!fs.existsSync(f)||!T[path.extname(f)])return new Response('x',{status:404});
 const dl=new URL(req.url).searchParams.get('dl');const buf=fs.readFileSync(f);
 return new Response(buf,{headers:{'Content-Type':T[path.extname(f)],'Cache-Control':club?'public,max-age=86400':'private,max-age=3600',...(dl?{'Content-Disposition':`attachment; filename="${base}"`}:{})}})}
