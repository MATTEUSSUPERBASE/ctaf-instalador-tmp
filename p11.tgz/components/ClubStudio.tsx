'use client';import ShareIG from './ShareIG';import StylePicker from './StylePicker';import AdvLogo from './AdvLogo';import {useState} from 'react';
const CATS=['Sub-9','Sub-11','Sub-13','Sub-15','Sub-17','Sub-20'];
const MB:Record<string,[string,string]>={jogo:['1 jogo','Um confronto'],jogos:['Vários jogos','Rodada por categoria'],result:['1 resultado','Placar de um jogo'],resultados:['Vários resultados','Placares por categoria'],evento:['Evento / Aviso','Post livre com foto']},MV:Record<string,[string,string]>={vjogo:['1 jogo','Um confronto'],vjogos:['Vários jogos','Rodada por categoria'],vevento:['Evento / Aviso','Aviso com foto'],vlivre:['Vídeo livre','Seu vídeo (treino, viagem...) com a marca']};
type G={cat:string;adv:string;hora:string;placar:string};const novo=(i=0):G=>({cat:CATS[Math.min(i+1,CATS.length-1)],adv:'',hora:'',placar:''});
export default function ClubStudio({inicial,camp}:{inicial:'banner'|'video';camp:string}){
 const tipo=inicial;const [mod,setMod]=useState(inicial==='video'?'vjogos':'jogos');const [fmt,setFmt]=useState('feed');const [advLogo,setAdvLogo]=useState('');const [foto,setFoto]=useState('');const [vid,setVid]=useState('');const [vn,setVn]=useState('');const [fb,setFb]=useState(false);const [tema,setTema]=useState('rand');const [fundo,setFundo]=useState('rand');
 const [d,setD]=useState({adv:'',data:'',hora:'',local:'',camp,placar:'',titulo:'',sub:''});const [js,setJs]=useState<G[]>([novo(0),novo(1)]);
 const [busy,setBusy]=useState(false);const [msg,setMsg]=useState('');const [res,setRes]=useState<{url:string;tipo:string}|null>(null);
 const lista=tipo==='banner'?MB:MV;const vl=mod==='vlivre';const ev=mod.endsWith('evento')||vl;const multi=mod.endsWith('s');const resu=mod.startsWith('result');
 const set=(k:string)=>(e:any)=>setD({...d,[k]:e.target.value});
 const setG=(i:number,k:keyof G,v:string)=>setJs(js.map((g,x)=>x===i?{...g,[k]:v}:g));
 async function upFoto(e:any){const f=e.target.files?.[0];if(!f)return;setFb(true);const fd=new FormData();fd.append('file',f);try{const r=await fetch('/api/evfoto',{method:'POST',body:fd});const j=await r.json();if(r.ok)setFoto(j.file);else setMsg('Não consegui usar essa foto.')}catch{setMsg('Falha no envio da foto.')}setFb(false);e.target.value=''}
 async function upVid(e:any){const f=e.target.files?.[0];if(!f)return;if(f.size>150e6){setMsg('Vídeo muito grande (máx. 150 MB).');return}setFb(true);setMsg('');const fd=new FormData();fd.append('file',f);try{const r=await fetch('/api/vlivre',{method:'POST',body:fd});const j=await r.json();if(r.ok){setVid(j.file);setVn(f.name)}else setMsg('Não consegui usar esse vídeo.')}catch{setMsg('Falha no envio do vídeo.')}setFb(false);e.target.value=''}
 async function criar(){setMsg('');setRes(null);setBusy(true);
  const r=await fetch('/api/club/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tipo,modelo:mod,formato:fmt,dados:{...d,tema,fundo,advLogo:multi?'':advLogo,foto,video:vid,jogos:multi?js:[]}})});
  if(!r.ok){setBusy(false);setMsg('Não foi possível criar. Tente de novo.');return}
  const {id}=await r.json();
  for(let i=0;i<160;i++){await new Promise(r=>setTimeout(r,1500));const j=await(await fetch('/api/club/jobs/'+id)).json();if(j.status==='pronto'){setRes({url:j.url,tipo:j.tipo});setBusy(false);return}if(j.status==='erro')break}
  setBusy(false);setMsg('Não foi possível criar. Tente de novo.')}
 const feed=tipo==='banner'&&fmt==='feed';
 return(<div className="studio"><div>
 <div className="pn"><h2>1 · Modelo</h2><p className="sub">Escolha o tipo de peça.</p>
  <div className="opts">{Object.entries(lista).map(([k,[t,s]])=><button key={k} className={mod===k?'on':''} onClick={()=>{setMod(k);setRes(null)}}>{t}<br/><span style={{fontWeight:500,fontSize:12,color:'#8A93A6'}}>{s}</span></button>)}</div>
  {tipo==='banner'&&<><label>Formato</label><div className="seg"><button className={fmt==='feed'?'on':''} onClick={()=>setFmt('feed')}>Feed 1080×1350</button><button className={fmt==='story'?'on':''} onClick={()=>setFmt('story')}>Story 1080×1920</button></div></>}</div>
 <div className="pn"><StylePicker tema={tema} fundo={fundo} onChange={(t,f)=>{setTema(t);setFundo(f)}}/></div>
  <div className="pn"><h2>2 · Dados</h2><p className="sub">{multi?'Informações comuns a todos os jogos da rodada.':'Informações do jogo.'}</p>
  {ev&&<><label>{vl?'Título (opcional)':'Título'}</label><input value={d.titulo} onChange={set('titulo')} placeholder="Festa de confraternização"/><label>Subtítulo (opcional)</label><input value={d.sub} onChange={set('sub')} placeholder="Venha comemorar com a gente"/>
   {vl?<><label>Seu vídeo (até 60 s)</label><div className="advl">{vid?<><span>🎬 {vn||'Vídeo enviado'}</span><button type="button" className="btn ghost sm" onClick={()=>{setVid('');setVn('')}}>Trocar</button></>:<label className="btn ghost sm" style={{display:'inline-block',cursor:'pointer'}}>{fb?'Enviando… aguarde':'🎬 Escolher vídeo'}<input type="file" accept="video/*" hidden onChange={upVid}/></label>}</div></>:<><label>Foto (opcional)</label><div className="advl">{foto?<><img src={`/api/files/${foto}`} alt=""/><span>Foto do post</span><button type="button" className="btn ghost sm" onClick={()=>setFoto('')}>Remover</button></>:<label className="btn ghost sm" style={{display:'inline-block',cursor:'pointer'}}>{fb?'Enviando…':'📷 Escolher foto'}<input type="file" accept="image/*" hidden onChange={upFoto}/></label>}{!foto&&<small>Sem foto, a arte usa o fundo do clube.</small>}</div></>}</>}
  {!multi&&!ev&&<><label>Adversário</label><input value={d.adv} onChange={set('adv')} placeholder="EC Fronteira"/><AdvLogo value={advLogo} onChange={setAdvLogo}/>{resu&&<><label>Placar</label><input value={d.placar} onChange={set('placar')} placeholder="3 × 1"/></>}</>}
  <div className="row"><div><label>Data</label><input value={d.data} onChange={set('data')} placeholder="Sáb, 29/11"/></div>{!multi&&!resu&&<div><label>Hora</label><input value={d.hora} onChange={set('hora')} placeholder="15h"/></div>}</div>
  <div className="row"><div><label>Local</label><input value={d.local} onChange={set('local')} placeholder="Estádio Municipal"/></div><div><label>{ev?'Etiqueta':'Campeonato'}</label><input value={d.camp} onChange={set('camp')} placeholder={ev?"EVENTO":"Copa Base"}/></div></div></div>
 {multi&&<div className="pn"><h2>3 · {resu?'Resultados':'Jogos'} por categoria</h2><p className="sub">Adicione uma linha para cada categoria que joga.</p>
  {js.map((g,i)=><div key={i} className="jrow">
   <select value={g.cat} onChange={e=>setG(i,'cat',e.target.value)} style={{width:110,flex:'none',marginBottom:0}}>{CATS.map(c=><option key={c}>{c}</option>)}</select>
   <input style={{flex:1,minWidth:0,marginBottom:0}} value={g.adv} onChange={e=>setG(i,'adv',e.target.value)} placeholder="Adversário"/>
   {resu?<input style={{width:90,flex:'none',marginBottom:0}} value={g.placar} onChange={e=>setG(i,'placar',e.target.value)} placeholder="3×1"/>:<input style={{width:80,flex:'none',marginBottom:0}} value={g.hora} onChange={e=>setG(i,'hora',e.target.value)} placeholder="15h"/>}
   <button className="btn ghost sm" style={{height:46}} onClick={()=>setJs(js.filter((_,x)=>x!==i))} aria-label="Remover linha">✕</button></div>)}
  {js.length<8&&<button className="btn ghost sm" style={{marginTop:6}} onClick={()=>setJs([...js,novo(js.length)])}>+ Adicionar categoria</button>}</div>}
 {msg&&<div className="err">{msg}</div>}
 <button className="btn" style={{padding:18}} disabled={busy||fb||(multi&&js.length===0)||(vl&&!vid)} onClick={criar}>{busy?'Gerando… aguarde':tipo==='video'?'Gerar vídeo':'Gerar arte'}</button></div>
 <div className="preview"><div className={'frame'+(feed?' feed':'')}><div className="scr">{busy?'Gerando a peça… leva alguns segundos':res?(res.tipo==='video'?<video src={res.url} controls playsInline autoPlay loop muted/>:<img src={res.url} alt=""/>):'A prévia aparece aqui depois de gerar'}</div>
  {res&&<ShareIG url={res.url} tipo={res.tipo} cls="btn ig dl"/>}{res&&<a className="btn ouro dl" href={res.url+'?dl=1'} download>Baixar {res.tipo==='video'?'vídeo (MP4)':'arte (PNG)'}</a>}</div></div></div>)}
