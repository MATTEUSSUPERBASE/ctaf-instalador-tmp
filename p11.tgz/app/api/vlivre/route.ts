import {NextResponse} from 'next/server';import fs from 'fs';import path from 'path';import crypto from 'crypto';import {DATA} from '@/lib/db';import {getSession} from '@/lib/auth';
export async function POST(req:Request){if(!(await getSession()))return NextResponse.json({erro:'x'},{status:401});
 const fd=await req.formData();const f=fd.get('file') as File|null;if(!f||f.size>150e6)return NextResponse.json({erro:'arquivo'},{status:400});
 const ext=(path.extname(f.name||'').slice(1).toLowerCase());const e=['mp4','mov','webm','m4v'].includes(ext)?ext:'mp4';
 const name=`vl-${crypto.randomBytes(6).toString('hex')}.${e}`;
 fs.writeFileSync(path.join(DATA,'uploads',name),Buffer.from(await f.arrayBuffer()));
 return NextResponse.json({ok:1,file:name})}
