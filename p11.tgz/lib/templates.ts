import fs from 'fs';import path from 'path';import club,{CLUB_DIR} from './club';import {db,DATA} from './db';
export type Dados={adv:string;data:string;hora:string;local:string;camp:string;placar?:string;tema?:string;advLogo?:string;fundo?:string;titulo?:string;sub?:string;foto?:string;video?:string;jogos?:{cat:string;adv:string;hora:string;placar:string}[]};
export type Ath={nome:string;numero:number;posicao:string;categoria:string};
const b64=(f:string,m:string)=>`data:${m};base64,${fs.readFileSync(f).toString('base64')}`;
let _fonts='',_crest='';
export function fontsCss(){if(_fonts)return _fonts;const d=path.join(process.cwd(),'public/fonts');
 _fonts=`@font-face{font-family:'Bebas Neue';src:url(${b64(d+'/bebas.woff2','font/woff2')})}`+[400,600,800,900].map(w=>`@font-face{font-family:Inter;font-weight:${w};src:url(${b64(`${d}/inter-${w}.woff2`,'font/woff2')})}`).join('');return _fonts}
const crestSrc=()=>_crest||(_crest=b64(path.join(CLUB_DIR,'crest.png'),'image/png'));
const crest=(s:number)=>`<img src="${crestSrc()}" width="${s}" height="${s}" style="display:block;border-radius:50%">`;
let ADVLOGO='';
const adv=(s:number,n:string)=>{const f=ADVLOGO?path.join(DATA,'uploads',ADVLOGO):'';
 if(f&&fs.existsSync(f))return `<div style="width:${s}px;height:${s}px;border-radius:50%;background:#fff;border:${s/30}px solid #fff;display:grid;place-items:center;overflow:hidden"><img src="${b64(f,'image/png')}" style="width:86%;height:86%;object-fit:contain"></div>`;
 const nm=String(n||'ADVERSÁRIO').toUpperCase(),lw=Math.max(...nm.split(/\s+/).map(w=>w.length)),fs2=Math.min(s*.26,(s*.66)/(Math.max(lw,4)*.5));
 return `<div style="width:${s}px;height:${s}px;border-radius:50%;background:#3A4256;border:${s/30}px solid #fff;display:flex;align-items:center;justify-content:center;overflow:hidden" class="bb"><div style="width:74%;text-align:center;font-size:${fs2}px;line-height:.98;word-break:break-word">${esc(nm)}</div></div>`};
const esc=(s:string)=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c] as string));
const person=(h:number,num:number,cut?:string)=>`<div style="position:absolute;left:0;right:0;bottom:0;height:${h}px;overflow:hidden"><div class="bb" style="position:absolute;left:0;right:0;text-align:center;top:${h*.02}px;font-size:${h*.85}px;color:§ACC§;opacity:.92">${num}</div>`+
 (cut?`<img src="${cut}" style="position:absolute;left:50%;bottom:0;transform:translateX(-50%);height:100%;max-width:100%;object-fit:contain;filter:drop-shadow(0 0 3px #fff) drop-shadow(0 24px 30px rgba(0,0,0,.65))">`:`<div style="position:absolute;inset:0;display:grid;place-items:center;font:800 26px Inter;letter-spacing:.2em;color:#8A93A6">FOTO DO ATLETA</div>`)+`</div>`;
const faixa=(bottom:number)=>{const sp=db.prepare('SELECT nome,logo FROM sponsors ORDER BY pos,id').all() as any[];
 const it=sp.length?sp.map(x=>{const f=x.logo?path.join(DATA,'uploads',x.logo):'';return f&&fs.existsSync(f)?`<img src="${b64(f,'image/png')}" style="height:84px;max-width:260px;object-fit:contain">`:`<span>${esc(x.nome)}</span>`}):club.patrocinadores.map(p=>`<span>${esc(p)}</span>`);
 return `<div style="position:absolute;left:0;right:0;bottom:${bottom}px;background:#fff;height:120px;display:flex;align-items:center;justify-content:space-around;color:§INK§;font:800 24px Inter">${it.join('')}</div>`};
const THEMES:any={noite:{BG:'#0B1121',BG2:'#1B2131',LT:'#34457a',GR:'11,17,33',ACC:'#F5C431',ACCTX:'#0B1121',BAND:'#D7141A',TX:'#fff',FG:'255,255,255',INK:'#0B1121'},
 vermelho:{BG:'#8E0D12',BG2:'#A3141A',LT:'#d1242b',GR:'142,13,18',ACC:'#F5C431',ACCTX:'#0B1121',BAND:'#0B1121',TX:'#fff',FG:'255,255,255',INK:'#0B1121'},
 ouro:{BG:'#F5C431',BG2:'#E6B41E',LT:'#fff0a8',GR:'245,196,49',ACC:'#D7141A',ACCTX:'#fff',BAND:'#0B1121',TX:'#0B1121',FG:'11,17,33',INK:'#0B1121'},
 gelo:{BG:'#F2F4F8',BG2:'#E3E7EF',LT:'#ffffff',GR:'242,244,248',ACC:'#D7141A',ACCTX:'#fff',BAND:'#0B1121',TX:'#0B1121',FG:'11,17,33',INK:'#0B1121'}};
const pick=(v:any,list:string[])=>list.includes(v)?v:list[Math.floor(Math.random()*list.length)];
let CUR:any=THEMES.noite,FUNDO='listras';
const setStyle=(j:Dados)=>{ADVLOGO=j.advLogo||'';CUR=THEMES[pick(j.tema,Object.keys(THEMES))];FUNDO=pick(j.fundo,['listras','pontos','luzes'])};
const tag=(j:Dados,top:number)=>{const t=String(j.camp||'').trim().toUpperCase();if(!t)return '';const lg=t.length>15,fs=lg?26:Math.min(34,330/(t.length*.62));top-=lg?14:0;
 return `<div style="position:absolute;right:70px;top:${top}px;max-width:380px;text-align:center;background:§ACC§;color:§ACCTX§;font:800 ${fs}px Inter;letter-spacing:.08em;padding:11px 24px;border-radius:${lg?30:99}px;white-space:${lg?'normal':'nowrap'};line-height:1.1;overflow:hidden;text-overflow:ellipsis;box-shadow:0 8px 22px rgba(0,0,0,.28)">${esc(t)}</div>`};
const bgc=()=>FUNDO==='pontos'?`background:radial-gradient(circle,§BG2§ 3.5px,transparent 4px) 0 0/32px 32px,§BG§`:FUNDO==='luzes'?`background:radial-gradient(ellipse 70% 45% at 12% 0%,§LT§ 0,transparent 100%),radial-gradient(ellipse 70% 45% at 88% 0%,§LT§ 0,transparent 100%),§BG§`:`background:linear-gradient(180deg,rgba(§GR§,.82),rgba(§GR§,.9)),repeating-linear-gradient(135deg,§BG2§ 0 6px,§BG§ 6px 18px)`;
const page=(w:number,h:number,inner:string)=>`<!DOCTYPE html><html><head><meta charset="utf-8"><style>${fontsCss()}*{margin:0;padding:0;box-sizing:border-box}body{width:${w}px;height:${h}px;overflow:hidden;background:§BG§}.bb{font-family:'Bebas Neue';letter-spacing:.02em;line-height:.9;text-transform:uppercase;font-weight:400}
@keyframes zoom{from{transform:scale(1)}to{transform:scale(1.12)}}@keyframes slide{from{transform:translateX(-120%)}to{transform:none}}@keyframes pop{0%{opacity:0;transform:scale(.6)}100%{opacity:1;transform:none}}</style></head><body>${inner}</body></html>`.replace(/§(\w+)§/g,(_:string,k:string)=>CUR[k]);
const rowsHtml=(res:boolean,js:NonNullable<Dados['jogos']>,top:number,rh:number,anim:boolean)=>js.map((g,i)=>`<div style="position:absolute;left:70px;right:70px;top:${top+i*rh}px;height:${rh-10}px;background:rgba(§FG§,.08);border-left:12px solid #D7141A;display:flex;align-items:center;gap:24px;padding:0 26px;${anim?`animation:slide .7s ${1+i*.15}s both;`:''}"><span class="bb" style="font-size:${rh*.46}px;color:§ACC§;width:${rh*2}px;flex:none">${esc(g.cat)}</span><span class="bb" style="font-size:${rh*.5}px;flex:1;white-space:nowrap;overflow:hidden;line-height:1.3;padding-top:.08em">${esc(g.adv)}</span><span class="bb" style="font-size:${rh*.5}px;color:${res?'#fff':'§ACC§'};flex:none">${esc(res?g.placar:g.hora)}</span></div>`).join('');
const multi=(res:boolean,j:Dados,h:number,pad:number,base:number)=>{const js=(j.jogos||[]).slice(0,8);const top=pad+560,avail=h-top-(base+120+40),rh=Math.min(130,Math.floor(avail/Math.max(js.length,1)));
 const t=res?'FIM DE<br><span style="color:§ACC§">JOGO</span>':club.chamadas.jogo[0]+'<br>'+club.chamadas.jogo[1].replace(club.curto,`<span style="color:§ACC§">${club.curto}</span>`);
 return `<div class="bb" style="position:absolute;left:70px;top:${pad+170}px;font-size:150px;line-height:.86">${t}</div><div style="position:absolute;left:70px;right:70px;top:${pad+440}px"><div class="bb" style="font-size:64px;margin-top:8px">${esc(j.data)} · ${esc(j.local)}</div></div>${rowsHtml(res,js,top,rh,false)}`};
const vmulti=(j:Dados)=>{const js=(j.jogos||[]).slice(0,8),rh=Math.min(110,Math.floor(600/Math.max(js.length,1)));return `<div style="position:absolute;left:70px;right:70px;top:300px"><div class="bb" style="font-size:70px;animation:pop 1s .6s both">${esc(j.data)} · ${esc(j.local)}</div></div>${rowsHtml(false,js,400,rh,true)}`};
const evImg=(j:Dados,vid:boolean)=>{const f=j.foto?path.join(DATA,'uploads',j.foto):'';if(!f||!fs.existsSync(f))return '';return `<div style="position:absolute;inset:0;${vid?'animation:zoom 6s ease-in-out infinite alternate;':''}"><img src="${b64(f,'image/jpeg')}" style="width:100%;height:100%;object-fit:cover"></div><div style="position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.92) 8%,rgba(0,0,0,.35) 55%,rgba(0,0,0,.55) 100%)"></div>`};
const evBody=(j:Dados,h:number,pad:number,base:number,vid:boolean)=>{const f=j.foto?path.join(DATA,'uploads',j.foto):'';const ph=f&&fs.existsSync(f)?b64(f,'image/jpeg'):'';
 const t=esc(String(j.titulo||'').toUpperCase()),n=t.length,fz=vid?(n>40?110:n>22?140:180):(n>40?100:n>22?130:170);
 const info=[j.data,j.hora,j.local].map(x=>String(x||'').trim()).filter(Boolean).map(esc).join(' · ');
 const bottom=vid?560:base+(h===1920?130:150);
 const img='';
 return `${img}<div style="position:absolute;left:70px;right:70px;bottom:${bottom}px;${vid?'animation:slide .9s .4s both':''}"><div style="width:120px;height:10px;background:§ACC§;margin-bottom:26px"></div><div class="bb" style="font-size:${fz}px;line-height:.9">${t||'EVENTO'}</div>${j.sub?`<div style="font:700 44px Inter;margin-top:24px;line-height:1.2">${esc(String(j.sub))}</div>`:''}${info?`<div style="font:800 34px Inter;letter-spacing:.1em;color:§ACC§;margin-top:26px;text-transform:uppercase">${info}</div>`:''}</div>`};
export function bannerHtml(m:string,a:Ath,j:Dados,h:1350|1920,cut?:string){setStyle(j);
 const pad=h===1920?250:70,base=h===1920?340:0,ph=h===1920?980:820;
 const head=`<div style="position:absolute;top:${pad}px;left:0;right:0;display:flex;justify-content:center">${crest(140)}</div>`;
 const wm=`<div style="position:absolute;right:-300px;bottom:${h===1920?420:140}px;opacity:.09">${crest(1000)}</div><div style="position:absolute;left:0;top:${pad+120}px;width:18px;height:300px;background:§BAND§"></div>`;
 let body='';
 const R=m==='result';if(m==='evento')body=evBody(j,h,pad,base,false);else if(m==='jogos'||m==='resultados')body=multi(m==='resultados',j,h,pad,base);else if(m==='jogo'||R)body=`<div class="bb" style="position:absolute;left:70px;top:${pad+185}px;font-size:205px;line-height:.86">${R?'FIM<br>DE <span style="color:§ACC§">JOGO</span>':club.chamadas.jogo[0]+'<br>'+club.chamadas.jogo[1].replace(club.curto,`<span style="color:§ACC§">${club.curto}</span>`)}</div>
 <div style="position:absolute;left:0;right:0;top:${pad+590}px;height:270px;background:§BAND§;color:#fff;display:flex;align-items:center;justify-content:center;gap:60px;box-shadow:0 20px 40px rgba(0,0,0,.5)">${crest(240)}<span class="bb" style="font-size:${R?190:230}px;margin-top:-10px;white-space:nowrap">${R?esc(j.placar||'0 × 0'):'×'}</span>${adv(240,j.adv)}</div>
 <div style="position:absolute;left:70px;right:70px;top:${pad+890}px"><div class="bb" style="font-size:130px;margin:14px 0 8px">${esc(j.data)}${R?'':' · '+esc(j.hora)}</div><div style="font:600 36px Inter">${esc(j.local)}</div></div>`;
 else{const sub:any={conv:'Chamado para o jogo contra '+j.adv,gol:`${club.curto} × ${j.adv}`,dest:'da rodada · '+j.camp,aniv:'Hoje é dia de '+a.nome.split(' ')[0]};
  body=`<div class="bb" style="position:absolute;left:70px;top:${pad+190}px;font-size:${m==='aniv'?150:190}px">${club.chamadas[m]}</div>${person(ph,a.numero,cut)}
  <div style="position:absolute;left:0;right:0;bottom:${base+120}px;height:420px;background:linear-gradient(0deg,§BG§ 15%,transparent)"></div>
  <div style="position:absolute;left:70px;right:70px;bottom:${base+140}px"><div class="bb" style="font-size:110px">${esc(a.nome)}</div><div style="font:800 28px Inter;letter-spacing:.14em;color:§ACC§;margin-top:12px">${esc(a.posicao).toUpperCase()} · ${esc(a.categoria)} · ${esc(sub[m])}</div></div>`}
 return page(1080,h,`<div style="position:relative;width:1080px;height:${h}px;${bgc()};overflow:hidden;color:§TX§">${m==='evento'?evImg(j,false):''}${wm}${head}${body}${tag(j,pad+42)}${faixa(base)}</div>`)}
export function videoHtml(v:string,a:Ath,j:Dados,cut?:string){setStyle(j);
 return page(1080,1920,`<div style="position:relative;width:1080px;height:1920px;${bgc()};overflow:hidden;color:§TX§">${v==='vevento'?evImg(j,true):''}
 <div style="position:absolute;inset:0;animation:zoom 6s ease-in-out infinite alternate"><div style="position:absolute;right:-300px;top:700px;opacity:.09">${crest(1000)}</div></div>
 <div style="position:absolute;top:250px;left:0;right:0;display:flex;justify-content:center;animation:pop .8s both">${crest(150)}</div>
 ${v=='vevento'?evBody(j,1920,250,0,true):`<div class="bb" style="position:absolute;left:70px;top:520px;font-size:200px;animation:slide .9s .3s both">${club.videos[v]}</div>`}
 <div style="position:absolute;left:0;right:0;bottom:340px;height:1000px;animation:pop 1s .8s both">${v==='vevento'?'':v==='vjogos'?vmulti(j):v==='apres'?person(720,a.numero,cut):`<div style="display:flex;justify-content:center;gap:50px;align-items:center;padding-top:400px">${crest(240)}<span class="bb" style="font-size:190px;color:§ACC§">×</span>${adv(240,j.adv)}</div><div style="text-align:center;margin-top:60px"><div class="bb" style="font-size:110px">${esc(j.data)} · ${esc(j.hora)}</div><div style="font:600 36px Inter;margin-top:14px">${esc(j.local)}</div></div>`}</div>
 ${v==='apres'?`<div style="position:absolute;left:70px;right:70px;bottom:480px;animation:slide .9s 1.2s both"><div class="bb" style="font-size:120px">${esc(a.nome)}</div><div style="font:800 30px Inter;letter-spacing:.14em;color:§ACC§;margin-top:12px">${esc(a.categoria)}</div></div>`:''}
 ${tag(j,300)}
 ${faixa(220)}</div>`)}

export function vlivreHtml(j:Dados){setStyle(j);const has=!!(j.titulo||j.sub||j.data||j.local);
 return page(1080,1920,`<style>body{background:transparent!important}</style><div style="position:relative;width:1080px;height:1920px;overflow:hidden;color:§TX§">
 <div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.55) 0,transparent 22%),linear-gradient(0deg,rgba(0,0,0,${has?'.9':'.6'}) 0,rgba(0,0,0,${has?'.55':'.2'}) 38%,transparent 62%)"></div>
 <div style="position:absolute;top:250px;left:0;right:0;display:flex;justify-content:center">${crest(150)}</div>
 ${has?evBody(j,1920,250,340,false):''}
 ${tag(j,300)}
 ${faixa(220)}</div>`)}
