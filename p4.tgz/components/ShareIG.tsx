'use client';import {useState} from 'react';
export default function ShareIG({url,tipo,cls='btn ig'}:{url:string;tipo:string;cls?:string}){
 const [m,setM]=useState('');const [b,setB]=useState(false);
 async function postar(){setM('');setB(true);try{
  const r=await fetch(url);const bl=await r.blob();const v=tipo==='video';const f=new File([bl],v?'ctaf.mp4':'ctaf.png',{type:v?'video/mp4':'image/png'});
  const nav:any=navigator;
  if(nav.canShare&&nav.canShare({files:[f]})){try{await nav.share({files:[f]})}catch(e){}}
  else{const a=document.createElement('a');a.href=URL.createObjectURL(bl);a.download=f.name;document.body.appendChild(a);a.click();a.remove();setM('Arquivo salvo. Abra o Instagram e escolha da galeria.')}
 }catch(e){setM('Não consegui compartilhar. Use o botão Baixar.')}setB(false)}
 return <><button className={cls} onClick={postar} disabled={b}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>{b?'Preparando…':'Postar no Instagram'}</button>{m&&<div className="igm">{m}</div>}</>}
