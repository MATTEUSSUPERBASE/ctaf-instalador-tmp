'use client';import ShareIG from './ShareIG';import {useState} from 'react';
const CATS=['Sub-9','Sub-11','Sub-13','Sub-15','Sub-17','Sub-20'];
const MB:Record<string,[string,string]>={jogo:['1 jogo','Um confronto'],jogos:['Vários jogos','Rodada por categoria'],result:['1 resultado','Placar de um jogo'],resultados:['Vários resultados','Placares por categoria']},MV:Record<string,[string,string]>={vjogo:['1 jogo','Um confronto'],vjogos:['Vários jogos','Rodada por categoria']};
type G={cat:string;adv:string;hora:string;placar:string};const novo=(i=0):G=>({cat:CATS[Math.min(i+1,CATS.length-1)],adv:'',hora:'',placar:''});
export default function ClubStudio({inicial,camp}:{inicial:'banner'|'video';camp:string}){
 const tipo=inicial;const [mod,setMod]=useState(inicial==='video'?'vjogos':'jogos');const [fmt,setFmt]=useState('feed');
 const [d,setD]=useState({adv:'',data:'',hora:'',local:'',camp,placar:''});const [js,setJs]=useState<G[]>([novo(0),novo(1)]);
 const [busy,setBusy]=useState(false);const [msg,setMsg]=useState('');const [res,setRes]=useState<{url:string;tipo:string}|null>(null);
 const lista=tipo==='banner'?MB:MV;const multi=mod.endsWith('s');const resu=mod.startsWith('result');
 const set=(k:string)=>(e:any)=>setD({...d,[k]:e.target.value});
 const setG=(i:number,k:keyof G,v:string)=>setJs(js.map((g,x)=>x===i?{...g,[k]:v}:g));
 async function criar(){setMsg('');setRes(null);setBusy(true);
  const r=await fetch('/api/club/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tipo,modelo:mod,formato:fmt,dados:{...d,jogos:multi?js:[]}})});
  if(!r.ok){setBusy(false);setMsg('Não foi possível criar. Tente de novo.');return}
  const {id}=await r.json();
  for(let i=0;i<160;i++){await new Promise(r=>setTimeout(r,1500));const j=await(await fetch('/api/club/jobs/'+id)).json();if(j.status==='pronto'){setRes({url:j.url,tipo:j.tipo});setBusy(false);return}if(j.status==='erro')break}
  setBusy(false);setMsg('Não foi possível criar. Tente de novo.')}
 const feed=tipo==='banner'&&fmt==='feed';
 return(<div className="studio"><div>
 <div className="pn"><h2>1 · Modelo</h2><p className="sub">Escolha o tipo de peça.</p>
  <div className="opts">{Object.entries(lista).map(([k,[t,s]])=><button key={k} className={mod===k?'on':''} onClick={()=>{setMod(k);setRes(null)}}>{t}<br/><span style={{fontWeight:500,fontSize:12,color:'#8A93A6'}}>{s}</span></button>)}</div>
  {tipo==='banner'&&<><label>Formato</label><div className="seg"><button className={fmt==='feed'?'on':''} onClick={()=>setFmt('feed')}>Feed 1080×1350</button><button className={fmt==='story'?'on':''} onClick={()=>setFmt('story')}>Story 1080×1920</button></div></>}</div>
 <div className="pn"><h2>2 · Dados</h2><p className="sub">{multi?'Informações comuns a todos os jogos da rodada.':'Informações do jogo.'}</p>
  {!multi&&<><label>Adversário</label><input value={d.adv} onChange={set('adv')} placeholder="EC Fronteira"/>{resu&&<><label>Placar</label><input value={d.placar} onChange={set('placar')} placeholder="3 × 1"/></>}</>}
  <div className="row"><div><label>Data</label><input value={d.data} onChange={set('data')} placeholder="Sáb, 29/11"/></div>{!multi&&!resu&&<div><label>Hora</label><input value={d.hora} onChange={set('hora')} placeholder="15h"/></div>}</div>
  <div className="row"><div><label>Local</label><input value={d.local} onChange={set('local')} placeholder="Estádio Municipal"/></div><div><label>Campeonato</label><input value={d.camp} onChange={set('camp')} placeholder="Copa Base"/></div></div></div>
 {multi&&<div className="pn"><h2>3 · {resu?'Resultados':'Jogos'} por categoria</h2><p className="sub">Adicione uma linha para cada categoria que joga.</p>
  {js.map((g,i)=><div key={i} className="jrow">
   <select value={g.cat} onChange={e=>setG(i,'cat',e.target.value)} style={{width:110,flex:'none',marginBottom:0}}>{CATS.map(c=><option key={c}>{c}</option>)}</select>
   <input style={{flex:1,minWidth:0,marginBottom:0}} value={g.adv} onChange={e=>setG(i,'adv',e.target.value)} placeholder="Adversário"/>
   {resu?<input style={{width:90,flex:'none',marginBottom:0}} value={g.placar} onChange={e=>setG(i,'placar',e.target.value)} placeholder="3×1"/>:<input style={{width:80,flex:'none',marginBottom:0}} value={g.hora} onChange={e=>setG(i,'hora',e.target.value)} placeholder="15h"/>}
   <button className="btn ghost sm" style={{height:46}} onClick={()=>setJs(js.filter((_,x)=>x!==i))} aria-label="Remover linha">✕</button></div>)}
  {js.length<8&&<button className="btn ghost sm" style={{marginTop:6}} onClick={()=>setJs([...js,novo(js.length)])}>+ Adicionar categoria</button>}</div>}
 {msg&&<div className="err">{msg}</div>}
 <button className="btn" style={{padding:18}} disabled={busy||(multi&&js.length===0)} onClick={criar}>{busy?'Gerando… aguarde':tipo==='video'?'Gerar vídeo':'Gerar arte'}</button></div>
 <div className="preview"><div className={'frame'+(feed?' feed':'')}><div className="scr">{busy?'Gerando a peça… leva alguns segundos':res?(res.tipo==='video'?<video src={res.url} controls playsInline autoPlay loop muted/>:<img src={res.url} alt=""/>):'A prévia aparece aqui depois de gerar'}</div>
  {res&&<ShareIG url={res.url} tipo={res.tipo} cls="btn ig dl"/>}{res&&<a className="btn ouro dl" href={res.url+'?dl=1'} download>Baixar {res.tipo==='video'?'vídeo (MP4)':'arte (PNG)'}</a>}</div></div></div>)}
