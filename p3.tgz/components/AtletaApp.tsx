'use client';import {useRef,useState} from 'react';import T from '@/texts/pt-BR.json';
export default function AtletaApp({code,cutout,usadas,limite,camp}:{code:string;cutout:string|null;usadas:number;limite:number;camp:string}){
 const [cut,setCut]=useState(cutout);const [tipo,setTipo]=useState<'banner'|'video'>('banner');const [mod,setMod]=useState('jogo');const [fmt,setFmt]=useState('feed');const [us,setUs]=useState(usadas);
 const [d,setD]=useState({adv:'',data:'',hora:'',local:'',camp});const [busy,setBusy]=useState('');const [msg,setMsg]=useState('');const [res,setRes]=useState<{url:string;tipo:string}|null>(null);const fi=useRef<HTMLInputElement>(null);
 const lista=tipo==='banner'?T.modelos:T.videos;const pickTipo=(t:'banner'|'video')=>{setTipo(t);setMod(t==='banner'?'jogo':'apres');setRes(null)};
 async function foto(e:React.ChangeEvent<HTMLInputElement>){const f=e.target.files?.[0];if(!f)return;setBusy('foto');setMsg('');const fd=new FormData();fd.append('file',f);const r=await fetch(`/api/a/${code}/photo`,{method:'POST',body:fd});setBusy('');if(r.ok){const j=await r.json();setCut(j.cutout);if(j.semFundoRemovido)setMsg('Não consegui remover o fundo desta foto. Tente outra foto, de preferência com o atleta inteiro e fundo mais simples.')}else setMsg(T.atleta.erro)}
 async function criar(){setMsg('');setRes(null);setBusy('criar');const r=await fetch(`/api/a/${code}/create`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tipo,modelo:mod,formato:fmt,dados:d})});
  if(!r.ok){const e=await r.json().catch(()=>({}));setBusy('');setMsg(e.erro==='limite'?T.atleta.esgotou:e.erro==='foto'?T.atleta.semFoto:T.atleta.erro);return}
  const {id}=await r.json();setUs(u=>u+1);
  for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,1500));const j=await(await fetch(`/api/jobs/${id}?code=${code}`)).json();if(j.status==='pronto'){setRes({url:j.url,tipo:j.tipo});setBusy('');return}if(j.status==='erro')break}
  setBusy('');setMsg(T.atleta.erro)}
 const set=(k:string)=>(e:any)=>setD({...d,[k]:e.target.value});
 return(<main><label className="photo"><input ref={fi} type="file" accept="image/*" hidden onChange={foto}/>{cut&&<img src={`/api/files/${cut}`} alt=""/>}{busy==='foto'?'Removendo o fundo… pode levar até 1 minuto':cut?T.atleta.fotoOk:'📷 '+T.atleta.foto}</label>
 <div className="tabs"><button className={tipo==='banner'?'on':''} onClick={()=>pickTipo('banner')}>{T.atleta.banner}</button><button className={tipo==='video'?'on':''} onClick={()=>pickTipo('video')}>{T.atleta.video}</button></div>
 <div className="kick">★ {T.atleta.modelo}</div><div className="chips">{Object.entries(lista).map(([k,v])=><button key={k} className={mod===k?'on':''} onClick={()=>{setMod(k);setRes(null)}}>{v as string}</button>)}</div>
 {tipo==='banner'&&<div className="tabs"><button className={fmt==='feed'?'on':''} onClick={()=>setFmt('feed')}>{T.atleta.feed}</button><button className={fmt==='story'?'on':''} onClick={()=>setFmt('story')}>{T.atleta.story}</button></div>}
 <div className="card"><div className="kick">{T.atleta.jogo}</div><label>{T.atleta.adv}</label><input value={d.adv} onChange={set('adv')} placeholder="EC Fronteira"/><div className="row"><div><label>{T.atleta.data}</label><input value={d.data} onChange={set('data')} placeholder="Sáb, 29/11"/></div><div><label>{T.atleta.hora}</label><input value={d.hora} onChange={set('hora')} placeholder="15h"/></div></div><label>{T.atleta.local}</label><input value={d.local} onChange={set('local')} placeholder="Estádio Municipal"/><label>{T.atleta.camp}</label><input value={d.camp} onChange={set('camp')}/></div>
 {msg&&<div className="err">{msg}</div>}
 {res&&<div className="res">{res.tipo==='video'?<video src={res.url} controls playsInline autoPlay loop muted/>:<img src={res.url} alt=""/>}<a className="btn ouro" href={res.url+'?dl=1'} download>{T.atleta.baixar}</a></div>}
 <div style={{fontSize:12,color:'var(--nevoa)',fontWeight:700,marginBottom:10}}>{T.atleta.limite}: {us} de {limite}</div>
 <button className="btn" disabled={!!busy||us>=limite} onClick={criar}>{busy==='criar'?T.atleta.criando:T.atleta.criar}</button></main>)}
