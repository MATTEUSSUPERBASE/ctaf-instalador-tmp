'use client';import {useRef,useState} from 'react';import {useRouter} from 'next/navigation';
export default function Sponsors({list}:{list:{id:number;nome:string;logo:string|null}[]}){const r=useRouter();const fi=useRef<HTMLInputElement>(null);const [nome,setNome]=useState('');const [busy,setBusy]=useState(false);const [msg,setMsg]=useState('');const [fn,setFn]=useState('');
 async function add(){const f=fi.current?.files?.[0];if(!nome.trim()&&!f){setMsg('Informe o nome ou escolha a logo.');return}setBusy(true);setMsg('');const fd=new FormData();fd.append('nome',nome);if(f)fd.append('file',f);
  const x=await fetch('/api/club/sponsors',{method:'POST',body:fd});setBusy(false);if(!x.ok){setMsg('Não foi possível salvar. Tente outra imagem.');return}setNome('');setFn('');if(fi.current)fi.current.value='';r.refresh()}
 async function del(id:number){if(!confirm('Remover este patrocinador das artes?'))return;await fetch('/api/club/sponsors',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});r.refresh()}
 return(<div className="two" style={{gridTemplateColumns:'minmax(0,1fr) 380px',alignItems:'start'}}>
 <div className="pn"><h2>Cadastrados ({list.length})</h2><p className="sub">{list.length?'Aparecem na ordem em que foram adicionados.':'Nenhum cadastrado. As artes mostram nomes provisórios até você adicionar.'}</p>
 <div className="spons">{list.map(s=><div key={s.id} className="sp"><div className="lg">{s.logo?<img src={'/api/files/'+s.logo} alt=""/>:s.nome}</div><b style={{fontSize:14}}>{s.nome}</b><button className="btn ghost sm" style={{width:'100%'}} onClick={()=>del(s.id)}>Remover</button></div>)}</div></div>
 <div className="pn"><h2>Adicionar</h2><p className="sub">Logo em PNG com fundo transparente fica melhor.</p>
 <label>Nome</label><input value={nome} onChange={e=>setNome(e.target.value)} placeholder="Mercado Central"/>
 <label>Logo</label><label className="photo" style={{marginBottom:12}}><input ref={fi} type="file" accept="image/*" hidden onChange={e=>setFn(e.target.files?.[0]?.name||'')}/>{fn||'Clique para escolher a imagem'}</label>
 {msg&&<div className="err">{msg}</div>}<button className="btn" disabled={busy} onClick={add}>{busy?'Salvando…':'Adicionar patrocinador'}</button></div></div>)}
