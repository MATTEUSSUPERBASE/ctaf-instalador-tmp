import Link from 'next/link';import club from '@/lib/club';import Crest from '@/components/Crest';import AtiStamp from '@/components/AtiStamp';import Logout from '@/components/Logout';
const I:Record<string,string>={
 home:'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
 art:'M4 4h16v16H4zM4 15l4-4 5 5 3-3 4 4M9 9h.01',
 film:'M4 4h16v16H4zM8 4v16M16 4v16M4 9h4M4 15h4M16 9h4M16 15h4',
 users:'M16 20v-2a4 4 0 00-4-4H7a4 4 0 00-4 4v2M9.5 10a3.5 3.5 0 100-7 3.5 3.5 0 000 7M21 20v-2a4 4 0 00-3-3.9M16 3.2a3.5 3.5 0 010 6.6',
 tag:'M20 12l-8 8-9-9V3h8zM7.5 7.5h.01',
 plus:'M12 5v14M5 12h14',bolt:'M13 2L4 14h7l-1 8 9-12h-7z'};
export const Ico=({n}:{n:string})=><svg viewBox="0 0 24 24"><path d={I[n]}/></svg>;
const NAV=[['/painel','Visão geral','home'],['/painel/artes','Artes do clube','art'],['/painel/artes?tipo=video','Vídeos do clube','film'],['/painel/novo','Novo atleta','plus'],['/painel/config','Patrocinadores','tag']];
export default function Shell({active,title,sub,actions,children}:{active:string;title:string;sub?:string;actions?:React.ReactNode;children:React.ReactNode}){
 return(<div className="shell"><aside className="side"><div className="brand"><Crest size={48}/><div><b>{club.curto}</b><span>{club.cidade}</span></div></div>
 <nav className="nav"><small>MENU</small>{NAV.map(([h,l,i])=><Link key={h} href={h} className={active===h?'on':''}><Ico n={i}/>{l}</Link>)}</nav>
 <div className="foot"><Logout cls="logout"/><AtiStamp/></div></aside>
 <section className="main-d"><div className="ptop"><div><h1>{title}</h1>{sub&&<p>{sub}</p>}</div>{actions&&<div className="btns">{actions}</div>}</div>{children}</section></div>)}
