export default function Crest({size=60}:{size?:number}){return <img src="/api/files/_club/crest.png" width={size} height={size} alt="" style={{display:'block',margin:'0 auto',borderRadius:'50%'}}/>}
