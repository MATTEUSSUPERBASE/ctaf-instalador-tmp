import T from '@/texts/pt-BR.json';
export default function AtiStamp(){return(<footer className="ati"><a href="https://atitech.io" target="_blank" rel="noopener">{T.carimbo}{' '}
<svg viewBox="300 130 980 520" fill="currentColor" aria-hidden="true"><path d="M305 642 663 135 980 642 833 642 791 575 562 575 630 473 735 473 654 342 450 642Z"/><path d="M690 135H1276L1180 256H1000L998 637 874 436 875 256H764Z"/><path d="M1183 270V642H1049V384Z"/></svg> ↗</a></footer>);}
