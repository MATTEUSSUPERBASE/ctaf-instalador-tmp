'use client';import {useState} from 'react';import T from '@/texts/pt-BR.json';
export default function CopyLink({code,className='btn ghost sm'}:{code:string;className?:string}){const [ok,setOk]=useState(false);
 return <button className={className} onClick={async()=>{const u=location.origin+'/a/'+code;try{await navigator.clipboard.writeText(u)}catch{prompt('Link:',u)}setOk(true);setTimeout(()=>setOk(false),1800)}}>{ok?T.painel.copiado:T.painel.copiar}</button>}
