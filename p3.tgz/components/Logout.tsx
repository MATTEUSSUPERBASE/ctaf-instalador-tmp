'use client';import T from '@/texts/pt-BR.json';
export default function Logout({cls='btn ghost sm'}:{cls?:string}){return <button className={cls} onClick={async()=>{await fetch('/api/logout',{method:'POST'});location.href='/login'}}>{T.painel.sair}</button>}
