import {NextResponse} from 'next/server';import sharp from 'sharp';import path from 'path';import crypto from 'crypto';import {db,DATA} from '@/lib/db';import {removeBg} from '@/lib/render';
export async function POST(req:Request,{params}:{params:Promise<{code:string}>}){const {code}=await params;
 const a:any=db.prepare('SELECT * FROM athletes WHERE code=? AND autorizado_em IS NOT NULL').get(code);if(!a)return NextResponse.json({erro:'x'},{status:404});
 const f=(await req.formData()).get('file') as File|null;if(!f||f.size>15e6)return NextResponse.json({erro:'arquivo'},{status:400});
 const id=crypto.randomBytes(6).toString('hex');const src=path.join(DATA,'uploads',`${a.id}-${id}-src.png`),cut=`${a.id}-${id}-cut.png`;
 await sharp(Buffer.from(await f.arrayBuffer())).rotate().resize({width:1100,height:1400,fit:'inside',withoutEnlargement:true}).png().toFile(src);
 const ok=await removeBg(src,path.join(DATA,'uploads',cut));
 if(!ok)await sharp(src).toFile(path.join(DATA,'uploads',cut));
 db.prepare('UPDATE athletes SET foto=?,cutout=? WHERE id=?').run(path.basename(src),cut,a.id);
 return NextResponse.json({ok:1,cutout:cut,semFundoRemovido:!ok})}
