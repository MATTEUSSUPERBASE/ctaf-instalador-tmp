import {notFound} from 'next/navigation';import {db,DAILY_LIMIT} from '@/lib/db';import club from '@/lib/club';import AtletaApp from '@/components/AtletaApp';import AtiStamp from '@/components/AtiStamp';import Crest from '@/components/Crest';import T from '@/texts/pt-BR.json';
export const dynamic='force-dynamic';
export default async function A({params}:{params:Promise<{code:string}>}){const {code}=await params;
 const a:any=db.prepare('SELECT * FROM athletes WHERE code=? AND autorizado_em IS NOT NULL').get(code);if(!a)notFound();
 const usadas=(db.prepare("SELECT COUNT(*) c FROM jobs WHERE athlete_id=? AND date(criado_em,'-3 hours')=date('now','-3 hours')").get(a.id) as any).c;
 return(<div className="mobile"><header className="top"><div style={{width:34}}><Crest size={34}/></div><div className="t"><b className="bb">{a.nome}</b><span>{T.atleta.area} · {a.categoria} · Nº {a.numero}</span></div></header>
 <AtletaApp code={code} cutout={a.cutout} usadas={usadas} limite={DAILY_LIMIT} camp={`Campeonato ${a.categoria}`}/><AtiStamp/></div>)}
