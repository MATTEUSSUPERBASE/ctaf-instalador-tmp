import LoginForm from '@/components/LoginForm';import club from '@/lib/club';
export default function P(){return <div className="mobile"><LoginForm nome={club.nome} cidade={club.cidade}/></div>}
