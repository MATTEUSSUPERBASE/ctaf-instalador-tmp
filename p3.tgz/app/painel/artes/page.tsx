import {redirect} from 'next/navigation';import {getSession} from '@/lib/auth';import Shell from '@/components/Shell';import ClubStudio from '@/components/ClubStudio';
export const dynamic='force-dynamic';
export default async function Artes({searchParams}:{searchParams:Promise<{tipo?:string}>}){if(!(await getSession()))redirect('/login');const {tipo}=await searchParams;const v=tipo==='video';
 return(<Shell active={v?'/painel/artes?tipo=video':'/painel/artes'} title={v?'Vídeos do clube':'Artes do clube'} sub="Preencha os dados e gere. O resultado aparece ao lado, pronto para baixar."><ClubStudio key={v?'v':'b'} inicial={v?'video':'banner'} camp=""/></Shell>)}
