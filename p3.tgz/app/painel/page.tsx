import {redirect} from 'next/navigation';import Link from 'next/link';import {getSession} from '@/lib/auth';import {db} from '@/lib/db';import T from '@/texts/pt-BR.json';
import Shell,{Ico} from '@/components/Shell';import CopyLink from '@/components/CopyLink';import DeleteAthlete from '@/components/DeleteAthlete';
export const dynamic='force-dynamic';
export default async function Painel(){if(!(await getSession()))redirect('/login');
 const ats=db.prepare('SELECT * FROM athletes ORDER BY nome').all() as any[];
 const q=(s:string)=>(db.prepare(s).get() as any).c;
 const mes=q("SELECT COUNT(*) c FROM jobs WHERE status='pronto' AND strftime('%Y-%m',criado_em,'-3 hours')=strftime('%Y-%m','now','-3 hours')");
 const sp=q('SELECT COUNT(*) c FROM sponsors');const pend=ats.filter(a=>!a.autorizado_em).length;
 return(<Shell active="/painel" title="Visão geral" sub="Crie artes e vídeos do clube e gerencie os atletas." actions={<Link className="btn inline" href="/painel/novo"><Ico n="plus"/>Novo atleta</Link>}>
 <div className="stat4">
  <div className="sc"><i><Ico n="users"/></i><b>{ats.length}</b><span>Atletas</span></div>
  <div className="sc"><i><Ico n="art"/></i><b>{mes}</b><span>Criações no mês</span></div>
  <div className={'sc'+(pend?' warn':'')}><i><Ico n="bolt"/></i><b>{pend}</b><span>Sem autorização</span></div>
  <div className="sc"><i><Ico n="tag"/></i><b>{sp}</b><span>Patrocinadores</span></div></div>
 <div className="quick">
  <Link className="qa" href="/painel/artes"><div className="ic"><Ico n="art"/></div><div><b>Arte do jogo</b><span>Jogos do dia e resultados · feed e story</span></div></Link>
  <Link className="qa" href="/painel/artes?tipo=video"><div className="ic"><Ico n="film"/></div><div><b>Vídeo do jogo</b><span>Vídeo vertical 9:16 pronto para Reels</span></div></Link>
  <Link className="qa" href="/painel/config"><div className="ic"><Ico n="tag"/></div><div><b>Patrocinadores</b><span>Logos que aparecem nas artes</span></div></Link></div>
 <div className="pn"><h2>Atletas</h2><p className="sub">Cada atleta recebe um link pessoal para criar as próprias artes.</p>
 <table className="tb"><thead><tr><th>Atleta</th><th>Categoria</th><th>Responsável</th><th>Status</th><th></th></tr></thead><tbody>
 {ats.length===0&&<tr><td colSpan={5} className="empty">{T.painel.vazio}</td></tr>}
 {ats.map(a=>(<tr key={a.id}><td><div className="nm"><div className="num">{a.numero}</div><div><b>{a.nome}</b><span>{a.posicao}</span></div></div></td><td>{a.categoria}</td><td>{a.resp_nome}</td>
 <td><span className={'pill '+(a.autorizado_em?'ok':'pen')}>{a.autorizado_em?T.painel.autorizado:T.painel.pendente}</span></td>
 <td><div className="ac"><CopyLink code={a.code}/><a className="btn ouro sm" href={'/a/'+a.code} target="_blank">{T.painel.abrir}</a><DeleteAthlete id={a.id} nome={a.nome}/></div></td></tr>))}
 </tbody></table></div></Shell>)}
