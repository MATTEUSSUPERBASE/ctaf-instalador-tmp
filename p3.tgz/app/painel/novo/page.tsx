import Shell from '@/components/Shell';import NovoForm from '@/components/NovoForm';import {getSession} from '@/lib/auth';import {redirect} from 'next/navigation';
export default async function Page(){if(!(await getSession()))redirect('/login');return(<Shell active="/painel/novo" title="Novo atleta" sub="Cadastre o atleta e envie o link pessoal para o responsável."><NovoForm/></Shell>)}
