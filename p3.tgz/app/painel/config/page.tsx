import {redirect} from 'next/navigation';import {getSession} from '@/lib/auth';import {db} from '@/lib/db';import Shell from '@/components/Shell';import Sponsors from '@/components/Sponsors';
export const dynamic='force-dynamic';
export default async function Config(){if(!(await getSession()))redirect('/login');const list=db.prepare('SELECT id,nome,logo FROM sponsors ORDER BY pos,id').all() as any[];
 return(<Shell active="/painel/config" title="Patrocinadores" sub="A faixa branca no rodapé das artes e dos vídeos mostra estes patrocinadores."><Sponsors list={list}/></Shell>)}
