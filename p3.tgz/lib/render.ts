import {chromium,Browser} from 'playwright';import sharp from 'sharp';import fs from 'fs';import path from 'path';import {spawn} from 'child_process';
import {DATA} from './db';import {bannerHtml,videoHtml,Ath,Dados} from './templates';
const g=globalThis as any;
async function browser():Promise<Browser>{if(!g.__br||!g.__br.isConnected())g.__br=await chromium.launch({args:['--no-sandbox'],executablePath:process.env.CHROMIUM_PATH||undefined});return g.__br}
const cutUri=(p?:string)=>p&&fs.existsSync(p)?`data:image/png;base64,${fs.readFileSync(p).toString('base64')}`:undefined;
export async function renderBanner(modelo:string,a:Ath,j:Dados,fmt:'feed'|'story',cutout:string|undefined,out:string){
 const h=fmt==='story'?1920:1350;const br=await browser();const pg=await br.newPage({viewport:{width:1080,height:h}});
 try{await pg.setContent(bannerHtml(modelo,a,j,h as any,cutUri(cutout)),{waitUntil:'load'});await pg.evaluate(()=>document.fonts.ready);
  const png=await pg.screenshot({type:'png'});await sharp(png).png({compressionLevel:9,palette:false}).toFile(out)}finally{await pg.close()}}
export async function renderVideo(modelo:string,a:Ath,j:Dados,cutout:string|undefined,out:string){
 const FPS=24,SEC=5,N=FPS*SEC;const br=await browser();const pg=await br.newPage({viewport:{width:1080,height:1920}});
 const tmp=fs.mkdtempSync(path.join(DATA,'frames-'));
 try{await pg.setContent(videoHtml(modelo,a,j,cutUri(cutout)),{waitUntil:'load'});await pg.evaluate(()=>document.fonts.ready);
  for(let i=0;i<N;i++){const t=(i/FPS)*1000;await pg.evaluate((t)=>{document.getAnimations().forEach(an=>{an.pause();an.currentTime=t})},t);
   await pg.screenshot({path:path.join(tmp,`f${String(i).padStart(3,'0')}.jpg`),type:'jpeg',quality:88})}
  await new Promise<void>((res,rej)=>{const p=spawn('ffmpeg',['-y','-framerate',String(FPS),'-i',path.join(tmp,'f%03d.jpg'),'-c:v','libx264','-pix_fmt','yuv420p','-crf','23','-preset','veryfast','-movflags','+faststart',out],{stdio:'ignore'});p.on('close',c=>c===0?res():rej(new Error('ffmpeg '+c)));p.on('error',rej)})}
 finally{await pg.close();fs.rmSync(tmp,{recursive:true,force:true})}}
let _bgq:Promise<any>=Promise.resolve();
export function removeBg(input:string,output:string):Promise<boolean>{
 const run=()=>new Promise<boolean>(res=>{const bin=process.env.REMBG_BIN||'rembg';let err='';
  const p=spawn(bin,['i',input,output],{stdio:['ignore','ignore','pipe']});
  const t=setTimeout(()=>{err+=' timeout';p.kill('SIGKILL')},240000);
  p.stderr?.on('data',d=>{err=(err+String(d)).slice(-600)});
  p.on('error',e=>{clearTimeout(t);console.error('rembg erro',e.message);res(false)});
  p.on('close',c=>{clearTimeout(t);const ok=c===0&&fs.existsSync(output)&&fs.statSync(output).size>2000;if(!ok)console.error('rembg falhou',c,err.slice(-300));res(ok)})});
 const r=_bgq.then(run,run);_bgq=r.catch(()=>0);return r}
