import {NextResponse} from 'next/server';import {db,DAILY_LIMIT} from '@/lib/db';import {kick} from '@/lib/queue';
const MOD=['jogo','conv','gol','dest','aniv'],VID=['apres','vjogo'];
export async function POST(req:Request,{params}:{params:Promise<{code:string}>}){const {code}=await params;
 const a:any=db.prepare('SELECT * FROM athletes WHERE code=? AND autorizado_em IS NOT NULL').get(code);if(!a)return NextResponse.json({erro:'x'},{status:404});
 const b=await req.json();const tipo=b.tipo==='video'?'video':'banner';
 if(tipo==='banner'?!MOD.includes(b.modelo):!VID.includes(b.modelo))return NextResponse.json({erro:'modelo'},{status:400});
 if(!a.cutout&&tipo==='video'&&b.modelo==='apres'||!a.cutout&&tipo==='banner'&&b.modelo!=='jogo')return NextResponse.json({erro:'foto'},{status:400});
 const usadas=(db.prepare("SELECT COUNT(*) c FROM jobs WHERE athlete_id=? AND date(criado_em,'-3 hours')=date('now','-3 hours')").get(a.id) as any).c;
 if(usadas>=DAILY_LIMIT)return NextResponse.json({erro:'limite'},{status:429});
 const pend=(db.prepare("SELECT COUNT(*) c FROM jobs WHERE athlete_id=? AND status IN('fila','fazendo')").get(a.id) as any).c;if(pend>=1)return NextResponse.json({erro:'aguarde'},{status:429});
 const s=(k:string,d='')=>String(b.dados?.[k]??d).slice(0,60);
 const dados=JSON.stringify({adv:s('adv'),data:s('data'),hora:s('hora'),local:s('local'),camp:s('camp'),tema:s('tema'),advLogo:/^adv-[a-f0-9]{12}\.png$/.test(String(b.dados?.advLogo))?String(b.dados.advLogo):'',fundo:s('fundo')});
 const r=db.prepare('INSERT INTO jobs(athlete_id,tipo,modelo,formato,dados) VALUES(?,?,?,?,?)').run(a.id,tipo,b.modelo,b.formato==='story'?'story':'feed',dados);
 kick();return NextResponse.json({id:r.lastInsertRowid,restantes:DAILY_LIMIT-usadas-1})}
