import {NextResponse} from 'next/server';import {db} from '@/lib/db';import {kick} from '@/lib/queue';import {getSession} from '@/lib/auth';
const MOD=['jogo','jogos','result','resultados'],VID=['vjogo','vjogos'];
export async function POST(req:Request){if(!(await getSession()))return NextResponse.json({erro:'x'},{status:401});
 const b=await req.json();const tipo=b.tipo==='video'?'video':'banner';
 if(tipo==='banner'?!MOD.includes(b.modelo):!VID.includes(b.modelo))return NextResponse.json({erro:'modelo'},{status:400});
 const pend=(db.prepare("SELECT COUNT(*) c FROM jobs WHERE athlete_id=0 AND status IN('fila','fazendo')").get() as any).c;if(pend>=2)return NextResponse.json({erro:'aguarde'},{status:429});
 const s=(k:string,d='')=>String(b.dados?.[k]??d).slice(0,60);
 const jogos=(Array.isArray(b.dados?.jogos)?b.dados.jogos:[]).slice(0,8).map((g:any)=>({cat:String(g?.cat??'').slice(0,12),adv:String(g?.adv??'').slice(0,30),hora:String(g?.hora??'').slice(0,10),placar:String(g?.placar??'').slice(0,10)}));
 const dados=JSON.stringify({adv:s('adv'),data:s('data'),hora:s('hora'),local:s('local'),camp:s('camp'),tema:s('tema'),advLogo:/^adv-[a-f0-9]{12}\.png$/.test(String(b.dados?.advLogo))?String(b.dados.advLogo):'',fundo:s('fundo'),placar:s('placar'),jogos});
 const r=db.prepare('INSERT INTO jobs(athlete_id,tipo,modelo,formato,dados) VALUES(0,?,?,?,?)').run(tipo,b.modelo,b.formato==='story'?'story':'feed',dados);
 kick();return NextResponse.json({id:r.lastInsertRowid})}
