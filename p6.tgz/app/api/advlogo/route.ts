import {NextResponse} from 'next/server';import sharp from 'sharp';import path from 'path';import crypto from 'crypto';import {db,DATA} from '@/lib/db';import {getSession} from '@/lib/auth';
export async function POST(req:Request){const fd=await req.formData();const code=String(fd.get('code')||'');
 const ok=(await getSession())||(code&&db.prepare('SELECT id FROM athletes WHERE code=? AND autorizado_em IS NOT NULL').get(code));if(!ok)return NextResponse.json({erro:'x'},{status:401});
 const f=fd.get('file') as File|null;if(!f||f.size>10e6)return NextResponse.json({erro:'arquivo'},{status:400});
 const name=`adv-${crypto.randomBytes(6).toString('hex')}.png`;
 try{await sharp(Buffer.from(await f.arrayBuffer())).rotate().resize({width:500,height:500,fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).png().toFile(path.join(DATA,'uploads',name))}catch{return NextResponse.json({erro:'imagem'},{status:400})}
 return NextResponse.json({ok:1,file:name})}
