'use client';import {useRef,useState} from 'react';
export default function AdvLogo({code,value,onChange}:{code?:string;value:string;onChange:(f:string)=>void}){
 const ref=useRef<HTMLInputElement>(null);const [b,setB]=useState(false);const [m,setM]=useState('');
 async function up(e:React.ChangeEvent<HTMLInputElement>){const f=e.target.files?.[0];if(!f)return;setB(true);setM('');const fd=new FormData();fd.append('file',f);if(code)fd.append('code',code);
  try{const r=await fetch('/api/advlogo',{method:'POST',body:fd});const j=await r.json();if(r.ok)onChange(j.file);else setM('Não consegui usar essa imagem.')}catch{setM('Falha no envio.')}setB(false);e.target.value=''}
 return <div className="advl"><input ref={ref} type="file" accept="image/*" hidden onChange={up}/>
  {value?<><img src={`/api/files/${value}`} alt=""/><span>Brasão do adversário</span><button type="button" className="btn ghost sm" onClick={()=>onChange('')}>Remover</button></>
  :<button type="button" className="btn ghost sm" onClick={()=>ref.current?.click()} disabled={b}>{b?'Enviando…':'🛡️ Brasão do adversário (opcional)'}</button>}
  {!value&&<small>Sem brasão, a arte usa só o nome.</small>}{m&&<small style={{color:'#ff8a8a'}}>{m}</small>}</div>}
