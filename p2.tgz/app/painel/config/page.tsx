import {redirect} from 'next/navigation';import Link from 'next/link';import {getSession} from '@/lib/auth';import {db} from '@/lib/db';import club from '@/lib/club';import AtiStamp from '@/components/AtiStamp';import Sponsors from '@/components/Sponsors';
export const dynamic='force-dynamic';
export default async function Config(){if(!(await getSession()))redirect('/login');const list=db.prepare('SELECT id,nome,logo FROM sponsors ORDER BY pos,id').all() as any[];
 return(<><header className="top"><Link className="btn ghost sm" href="/painel">←</Link><div className="t"><b className="bb">Patrocinadores</b><span>{club.nome}</span></div></header><Sponsors list={list}/><AtiStamp/></>)}
