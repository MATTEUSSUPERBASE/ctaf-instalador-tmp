import {redirect} from 'next/navigation';import Link from 'next/link';import {getSession} from '@/lib/auth';import {db} from '@/lib/db';import club from '@/lib/club';
import T from '@/texts/pt-BR.json';import Crest from '@/components/Crest';import AtiStamp from '@/components/AtiStamp';import CopyLink from '@/components/CopyLink';import Logout from '@/components/Logout';import DeleteAthlete from '@/components/DeleteAthlete';
export const dynamic='force-dynamic';
export default async function Painel(){if(!(await getSession()))redirect('/login');
 const ats=db.prepare('SELECT * FROM athletes ORDER BY nome').all() as any[];
 const mes=(db.prepare("SELECT COUNT(*) c FROM jobs WHERE status='pronto' AND strftime('%Y-%m',criado_em,'-3 hours')=strftime('%Y-%m','now','-3 hours')").get() as any).c;
 const pend=ats.filter(a=>!a.autorizado_em).length;
 return(<><header className="top"><div style={{width:38}}><Crest size={38}/></div><div className="t"><b className="bb">{T.painel.titulo}</b><span>{club.nome}</span></div><Logout/></header>
 <main><div className="stats"><div><b>{ats.length}</b><span>{T.painel.atletas.toUpperCase()}</span></div><div><b>{mes}</b><span>{T.painel.criacoes.toUpperCase()}</span></div><div><b>{pend}</b><span>{T.painel.pendentes.toUpperCase()}</span></div></div>
 <div className="acts" style={{border:0,marginBottom:14}}><Link className="btn ouro sm" href="/painel/artes">🎨 Artes do clube</Link><Link className="btn ouro sm" href="/painel/artes?tipo=video">🎬 Vídeos do clube</Link><Link className="btn ghost sm" href="/painel/config">⚙️ Patrocinadores</Link></div>
 <div className="kick">★ {T.painel.atletas}</div>
 <div className="card">{ats.length===0&&<p style={{color:'var(--nevoa)',fontSize:13}}>{T.painel.vazio}</p>}{ats.map(a=>(<div key={a.id}><div className="ath"><div className="num">{a.numero}</div><div className="i"><b>{a.nome}</b><span>{a.posicao} · {a.categoria} · Resp.: {a.resp_nome}</span></div><span className={'pill '+(a.autorizado_em?'ok':'pen')}>{a.autorizado_em?T.painel.autorizado:T.painel.pendente}</span></div>
 <div className="acts"><CopyLink code={a.code}/><a className="btn ouro sm" href={'/a/'+a.code} target="_blank">{T.painel.abrir}</a><DeleteAthlete id={a.id} nome={a.nome}/></div></div>))}</div>
 <Link className="btn" href="/painel/novo">+ {T.painel.novo}</Link></main><AtiStamp/></>)}
