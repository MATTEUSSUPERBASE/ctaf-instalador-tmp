import {redirect} from 'next/navigation';import Link from 'next/link';import {getSession} from '@/lib/auth';import club from '@/lib/club';import AtiStamp from '@/components/AtiStamp';import ClubStudio from '@/components/ClubStudio';
export const dynamic='force-dynamic';
export default async function Artes({searchParams}:{searchParams:Promise<{tipo?:string}>}){if(!(await getSession()))redirect('/login');const {tipo}=await searchParams;
 return(<><header className="top"><Link className="btn ghost sm" href="/painel">←</Link><div className="t"><b className="bb">Artes e vídeos do clube</b><span>{club.nome}</span></div></header>
 <ClubStudio inicial={tipo==='video'?'video':'banner'} camp={(club as any).campeonato||''}/><AtiStamp/></>)}
