import {NextResponse} from 'next/server';import {db} from '@/lib/db';import {getSession} from '@/lib/auth';
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){if(!(await getSession()))return NextResponse.json({erro:'x'},{status:401});const {id}=await params;
 const j:any=db.prepare('SELECT status,arquivo,tipo FROM jobs WHERE id=? AND athlete_id=0').get(id);if(!j)return NextResponse.json({erro:'x'},{status:404});
 return NextResponse.json({status:j.status,tipo:j.tipo,url:j.arquivo?`/api/files/${j.arquivo}`:null})}
