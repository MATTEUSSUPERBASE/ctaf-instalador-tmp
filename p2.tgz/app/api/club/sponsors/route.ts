import {NextResponse} from 'next/server';import sharp from 'sharp';import fs from 'fs';import path from 'path';import {db,DATA} from '@/lib/db';import {getSession} from '@/lib/auth';
export async function POST(req:Request){if(!(await getSession()))return NextResponse.json({erro:'auth'},{status:401});
 const fd=await req.formData();const nome=String(fd.get('nome')||'').trim().slice(0,40);const f=fd.get('file') as File|null;
 if(!nome&&!(f&&f.size))return NextResponse.json({erro:'dados'},{status:400});
 const r=db.prepare('INSERT INTO sponsors(nome,pos) VALUES(?,(SELECT COALESCE(MAX(pos),0)+1 FROM sponsors))').run(nome||'Patrocinador');let logo='';
 if(f&&f.size){try{logo=`sp-${r.lastInsertRowid}.png`;await sharp(Buffer.from(await f.arrayBuffer())).resize(520,200,{fit:'inside'}).png().toFile(path.join(DATA,'uploads',logo));db.prepare('UPDATE sponsors SET logo=? WHERE id=?').run(logo,r.lastInsertRowid)}catch{db.prepare('DELETE FROM sponsors WHERE id=?').run(r.lastInsertRowid);return NextResponse.json({erro:'imagem'},{status:400})}}
 return NextResponse.json({ok:1})}
export async function DELETE(req:Request){if(!(await getSession()))return NextResponse.json({erro:'auth'},{status:401});const {id}=await req.json();
 const s:any=db.prepare('SELECT logo FROM sponsors WHERE id=?').get(id);if(s?.logo)try{fs.unlinkSync(path.join(DATA,'uploads',s.logo))}catch{}
 db.prepare('DELETE FROM sponsors WHERE id=?').run(id);return NextResponse.json({ok:1})}
