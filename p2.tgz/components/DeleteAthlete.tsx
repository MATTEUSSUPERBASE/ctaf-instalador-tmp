'use client';import {useRouter} from 'next/navigation';
export default function DeleteAthlete({id,nome}:{id:number;nome:string}){const r=useRouter();
 return <button className="btn ghost sm" onClick={async()=>{if(!confirm(`Remover ${nome}? O link dele deixa de funcionar.`))return;await fetch('/api/athletes',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});r.refresh()}}>Remover</button>}
