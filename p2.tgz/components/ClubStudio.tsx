'use client';import {useState} from 'react';import T from '@/texts/pt-BR.json';
const CATS=['Sub-9','Sub-11','Sub-13','Sub-15','Sub-17','Sub-20'];
const MB:Record<string,string>={jogo:'1 jogo',jogos:'Vários jogos',result:'1 resultado',resultados:'Vários resultados'},MV:Record<string,string>={vjogo:'1 jogo',vjogos:'Vários jogos'};
type G={cat:string;adv:string;hora:string;placar:string};const novo=(i=0):G=>({cat:CATS[Math.min(i+1,CATS.length-1)],adv:'',hora:'',placar:''});
export default function ClubStudio({inicial,camp}:{inicial:'banner'|'video';camp:string}){
 const [tipo,setTipo]=useState<'banner'|'video'>(inicial);const [mod,setMod]=useState(inicial==='video'?'vjogos':'jogos');const [fmt,setFmt]=useState('feed');
 const [d,setD]=useState({adv:'',data:'',hora:'',local:'',camp,placar:''});const [js,setJs]=useState<G[]>([novo(0),novo(1)]);
 const [busy,setBusy]=useState(false);const [msg,setMsg]=useState('');const [res,setRes]=useState<{url:string;tipo:string}|null>(null);
 const pick=(t:'banner'|'video')=>{setTipo(t);setMod(t==='banner'?'jogos':'vjogos');setRes(null)};
 const lista=tipo==='banner'?MB:MV;const multi=mod.endsWith('s');const resu=mod.startsWith('result');
 const set=(k:string)=>(e:any)=>setD({...d,[k]:e.target.value});
 const setG=(i:number,k:keyof G,v:string)=>setJs(js.map((g,x)=>x===i?{...g,[k]:v}:g));
 async function criar(){setMsg('');setRes(null);setBusy(true);
  const r=await fetch('/api/club/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tipo,modelo:mod,formato:fmt,dados:{...d,jogos:multi?js:[]}})});
  if(!r.ok){setBusy(false);setMsg(T.atleta.erro);return}
  const {id}=await r.json();
  for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,1500));const j=await(await fetch('/api/club/jobs/'+id)).json();if(j.status==='pronto'){setRes({url:j.url,tipo:j.tipo});setBusy(false);return}if(j.status==='erro')break}
  setBusy(false);setMsg(T.atleta.erro)}
 return(<main>
 <div className="tabs"><button className={tipo==='banner'?'on':''} onClick={()=>pick('banner')}>Artes do clube</button><button className={tipo==='video'?'on':''} onClick={()=>pick('video')}>Vídeos do clube</button></div>
 <div className="kick">★ {T.atleta.modelo}</div><div className="chips">{Object.entries(lista).map(([k,v])=><button key={k} className={mod===k?'on':''} onClick={()=>{setMod(k);setRes(null)}}>{v}</button>)}</div>
 {tipo==='banner'&&<div className="tabs"><button className={fmt==='feed'?'on':''} onClick={()=>setFmt('feed')}>{T.atleta.feed}</button><button className={fmt==='story'?'on':''} onClick={()=>setFmt('story')}>{T.atleta.story}</button></div>}
 <div className="card"><div className="kick">{multi?'Dados da rodada':T.atleta.jogo}</div>
 {!multi&&<><label>{T.atleta.adv}</label><input value={d.adv} onChange={set('adv')} placeholder="EC Fronteira"/>{resu&&<><label>Placar</label><input value={d.placar} onChange={set('placar')} placeholder="3 × 1"/></>}</>}
 <div className="row"><div><label>{T.atleta.data}</label><input value={d.data} onChange={set('data')} placeholder="Sáb, 29/11"/></div>{!multi&&!resu&&<div><label>{T.atleta.hora}</label><input value={d.hora} onChange={set('hora')} placeholder="15h"/></div>}</div>
 <label>{T.atleta.local}</label><input value={d.local} onChange={set('local')} placeholder="Estádio Municipal"/><label>{T.atleta.camp}</label><input value={d.camp} onChange={set('camp')}/></div>
 {multi&&<div className="card"><div className="kick">{resu?'Resultados por categoria':'Jogos por categoria'}</div>
  {js.map((g,i)=><div key={i} style={{display:'flex',gap:6,marginBottom:8,alignItems:'center'}}>
   <select value={g.cat} onChange={e=>setG(i,'cat',e.target.value)} style={{width:92,flex:'none'}}>{CATS.map(c=><option key={c}>{c}</option>)}</select>
   <input style={{flex:1,minWidth:0}} value={g.adv} onChange={e=>setG(i,'adv',e.target.value)} placeholder="Adversário"/>
   {resu?<input style={{width:70,flex:'none'}} value={g.placar} onChange={e=>setG(i,'placar',e.target.value)} placeholder="3×1"/>:<input style={{width:62,flex:'none'}} value={g.hora} onChange={e=>setG(i,'hora',e.target.value)} placeholder="15h"/>}
   <button className="btn ghost sm" onClick={()=>setJs(js.filter((_,x)=>x!==i))} aria-label="Remover">✕</button></div>)}
  {js.length<8&&<button className="btn ghost sm" onClick={()=>setJs([...js,novo(js.length)])}>+ Adicionar jogo</button>}</div>}
 {msg&&<div className="err">{msg}</div>}
 {res&&<div className="res">{res.tipo==='video'?<video src={res.url} controls playsInline autoPlay loop muted/>:<img src={res.url} alt=""/>}<a className="btn ouro" href={res.url+'?dl=1'} download>{T.atleta.baixar}</a></div>}
 <button className="btn" disabled={busy||(multi&&js.length===0)} onClick={criar}>{busy?T.atleta.criando:T.atleta.criar}</button></main>)}
