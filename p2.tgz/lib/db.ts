import Database from 'better-sqlite3';import fs from 'fs';import path from 'path';
export const DATA=process.env.DATA_DIR||path.join(process.cwd(),'data');
fs.mkdirSync(path.join(DATA,'uploads'),{recursive:true});fs.mkdirSync(path.join(DATA,'out'),{recursive:true});
const g=globalThis as any;
export const db:Database.Database=g.__db??=(()=>{const d=new Database(path.join(DATA,'app.db'));d.pragma('journal_mode = WAL');d.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,hash TEXT,salt TEXT);
CREATE TABLE IF NOT EXISTS athletes(id INTEGER PRIMARY KEY,code TEXT UNIQUE,nome TEXT,numero INTEGER,posicao TEXT,categoria TEXT,resp_nome TEXT,resp_whats TEXT,autorizado_em TEXT,foto TEXT,cutout TEXT,criado_em TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,athlete_id INTEGER,tipo TEXT,modelo TEXT,formato TEXT,dados TEXT,status TEXT DEFAULT 'fila',arquivo TEXT,erro TEXT,criado_em TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sponsors(id INTEGER PRIMARY KEY,nome TEXT,logo TEXT,pos INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS jobs_ath ON jobs(athlete_id,criado_em);`);return d})();
export const DAILY_LIMIT=Number(process.env.DAILY_LIMIT||5);
