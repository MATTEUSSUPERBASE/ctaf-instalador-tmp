'use client';
const TEMAS:[string,string,string][]=[['rand','Aleatório','conic-gradient(#0B1121,#8E0D12,#F5C431,#F2F4F8,#0B1121)'],['noite','Noite','#0B1121'],['vermelho','Vermelho','#8E0D12'],['ouro','Ouro','#F5C431'],['gelo','Gelo','#F2F4F8']];
const FUNDOS:[string,string][]=[['rand','Aleatório'],['listras','Listras'],['pontos','Pontos'],['luzes','Luzes']];
export default function StylePicker({tema,fundo,onChange}:{tema:string;fundo:string;onChange:(t:string,f:string)=>void}){
 return <div className="sty"><div className="kick">★ Estilo da arte</div>
  <div className="swa">{TEMAS.map(([k,l,c])=><button key={k} type="button" className={tema===k?'on':''} onClick={()=>onChange(k,fundo)}><i style={{background:c}}/>{l}</button>)}</div>
  <div className="chips fnd">{FUNDOS.map(([k,l])=><button key={k} type="button" className={fundo===k?'on':''} onClick={()=>onChange(tema,k)}>{l}</button>)}</div></div>}
